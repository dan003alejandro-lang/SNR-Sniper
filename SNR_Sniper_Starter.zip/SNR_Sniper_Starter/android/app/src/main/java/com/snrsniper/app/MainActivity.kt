package com.snrsniper.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var baseUrl: EditText
    private lateinit var apiKey: EditText
    private lateinit var status: TextView
    private lateinit var details: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(17, 24, 39)
        window.navigationBarColor = Color.rgb(17, 24, 39)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 28)
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        val scroll = ScrollView(this)
        val title = TextView(this).apply {
            text = "SNR SNIPER"
            textSize = 26f
            setTextColor(Color.rgb(17, 24, 39))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        page.addView(title)
        page.addView(label("Control de trading · Exness XAUUSDm"))
        status = label("● DESCONECTADO · MODO SEGURO")
        status.setTextColor(Color.rgb(153, 27, 27))
        page.addView(status)
        page.addView(label("URL HTTPS del servidor"))
        baseUrl = EditText(this).apply {
            hint = "https://tu-servidor.example"
            singleLine = true
            setTextColor(Color.BLACK)
        }
        page.addView(baseUrl)
        page.addView(label("Clave de acceso a la API (no es tu contraseña de Exness)"))
        apiKey = EditText(this).apply {
            hint = "Clave API"
            singleLine = true
            inputType = 129
            setTextColor(Color.BLACK)
        }
        page.addView(apiKey)
        val refresh = actionButton("Consultar estado") { request("GET", "/status", null) }
        page.addView(refresh)
        val pause = actionButton("PAUSAR nuevas entradas") {
            request("POST", "/control", JSONObject().put("command", "pause"))
        }
        page.addView(pause)
        val resume = actionButton("HABILITAR modo demo") {
            request("POST", "/control", JSONObject().put("command", "demo_enable"))
        }
        page.addView(resume)
        details = label("Aún no hay conexión con el servidor.\n\nLa habilitación demo solo funcionará cuando el backend esté instalado y protegido.")
        page.addView(details)
        val warning = label("IMPORTANTE: esta versión es un panel inicial. No envía órdenes directamente a Exness y no debe usarse con dinero real.")
        warning.setTextColor(Color.rgb(153, 27, 27))
        page.addView(warning)
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 15f
        setTextColor(Color.rgb(55, 65, 81))
        setPadding(0, 12, 0, 8)
    }

    private fun actionButton(caption: String, action: () -> Unit) = Button(this).apply {
        text = caption
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun request(method: String, path: String, body: JSONObject?) {
        val root = baseUrl.text.toString().trim().trimEnd('/')
        val key = apiKey.text.toString().trim()
        if (!root.startsWith("https://") || key.isBlank()) {
            status.text = "● FALTA CONFIGURACIÓN HTTPS / CLAVE"
            details.text = "Introduce la URL HTTPS de tu API y una clave propia. No uses credenciales de Exness."
            return
        }
        status.text = "● CONSULTANDO SERVIDOR…"
        executor.execute {
            try {
                val conn = (URL(root + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    connectTimeout = 7000
                    readTimeout = 7000
                    setRequestProperty("Authorization", "Bearer $key")
                    setRequestProperty("Content-Type", "application/json")
                    if (body != null) {
                        doOutput = true
                        outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    }
                }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() } ?: "Sin respuesta"
                conn.disconnect()
                runOnUiThread {
                    status.text = if (code in 200..299) "● SERVIDOR CONECTADO" else "● ERROR HTTP $code"
                    details.text = try { JSONObject(text).toString(2) } catch (_: Exception) { text }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "● NO CONECTADO"
                    details.text = "No se pudo conectar: ${e.message ?: "error de red"}. Comprueba la URL, el certificado HTTPS y que el servidor esté activo."
                }
            }
        }
    }
}
