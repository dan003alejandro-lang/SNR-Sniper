# SNR Sniper — starter técnico

**Objetivo:** panel Android para controlar, de forma autenticada, un servicio puente que posteriormente se conectará con un EA de MetaTrader 5 para Exness `XAUUSDm`.

## Estado real de esta entrega

- Incluye el código fuente inicial del panel Android, una API de prueba y un esqueleto documental del EA.
- **No es todavía un bot listo para operar ni un APK compilado.** En este entorno no hay Android SDK/Gradle instalado para compilar y probar el APK.
- La API de esta entrega es un prototipo local: no conectarla a una cuenta real ni exponerla directamente a Internet.
- No incluye todavía la lógica SNR validada, la conexión MT5 ↔ API, ni gestión real de órdenes. Eso es una fase posterior que debe probarse en demo.

## Estructura

- `android/`: proyecto Android nativo Kotlin.
- `backend/`: API FastAPI de demostración.
- `mt5/`: notas del EA y del protocolo previsto.
- `.github/workflows/android-apk.yml`: compilación cloud de prueba mediante GitHub Actions.

## Seguridad imprescindible antes de cualquier cuenta real

1. Usar HTTPS con certificado válido.
2. Crear una clave aleatoria larga y exclusiva; no reutilizar contraseñas de Exness.
3. No guardar credenciales de trading dentro del APK.
4. Proteger los endpoints y limitar el acceso al VPS con firewall.
5. Comenzar con `EnableTrading=false` y una cuenta demo.
6. Añadir límites de riesgo, pérdida diaria, spread máximo, número de operaciones y botón de parada antes de activar órdenes reales.

## Compilar el APK desde Android

Este repositorio incluye un workflow para compilar en GitHub Actions. Sube el contenido de esta carpeta a un repositorio privado de GitHub y ejecuta el workflow `Build Android APK`. Al finalizar, descarga el artefacto `snr-sniper-debug-apk` desde la ejecución del workflow. La compilación cloud puede requerir ajustes según cambios de las herramientas Android; revisa los logs. No instales APKs de fuentes desconocidas.

## Ejecutar API de demostración (solo desarrollo)

En un entorno Python 3.11+:

```bash
cd backend
pip install -r requirements.txt
# Cambia la clave de demostración antes de cualquier prueba
set SNR_API_KEY=CAMBIA_ESTA_CLAVE_LARGA
uvicorn app:app --host 127.0.0.1 --port 8000
```

La API escucha en `127.0.0.1` para no exponerla por accidente. La aplicación Android requiere la URL base de una API accesible por HTTPS para pruebas reales.
