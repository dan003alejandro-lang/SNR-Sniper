"""Demonstration-only API for the SNR Sniper Android panel.
Not connected to MetaTrader 5. Do not expose publicly or use for live trading.
"""
import hmac
import os
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

app = FastAPI(title="SNR Sniper Control API", version="0.1.0")
API_KEY = os.getenv("SNR_API_KEY", "")
state = {"mode": "SAFE_OFF", "connected_to_mt5": False, "symbol": "XAUUSDm", "broker": "Exness", "open_positions": 0, "last_signal": None, "note": "Demo API only; MT5 bridge not implemented."}

class Control(BaseModel):
    command: str

def authorize(authorization: str | None):
    if not API_KEY or API_KEY == "CAMBIA_ESTA_CLAVE_LARGA":
        raise HTTPException(status_code=503, detail="Configure a unique SNR_API_KEY before use")
    expected = "Bearer " + API_KEY
    if not authorization or not hmac.compare_digest(authorization, expected):
        raise HTTPException(status_code=401, detail="Unauthorized")

@app.get("/health")
def health():
    return {"ok": True, "service": "snr-sniper-demo", "trading_enabled": False}

@app.get("/status")
def get_status(authorization: str | None = Header(default=None)):
    authorize(authorization)
    return state

@app.post("/control")
def control(command: Control, authorization: str | None = Header(default=None)):
    authorize(authorization)
    if command.command == "pause":
        state["mode"] = "PAUSED"
        state["note"] = "Pause recorded in demo API; not connected to MT5."
    elif command.command == "demo_enable":
        state["mode"] = "DEMO_REQUESTED"
        state["note"] = "Demo request recorded only; no trades can be placed by this prototype."
    else:
        raise HTTPException(status_code=400, detail="Unsupported command")
    return {"accepted": True, "state": state}
