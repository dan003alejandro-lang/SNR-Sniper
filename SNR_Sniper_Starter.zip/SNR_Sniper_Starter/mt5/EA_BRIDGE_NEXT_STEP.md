# MT5 EA bridge — siguiente fase

El EA definitivo debe ejecutarse en MT5 de escritorio dentro del VPS y conectarse con el backend mediante `WebRequest` a una URL HTTPS permitida en las opciones de MT5.

Antes de escribir la integración completa, deben definirse y probarse:

- Lectura de comandos autenticados desde el backend y publicación de estado.
- Reglas reproducibles de SNR: zona, frescura, segundo movimiento, rechazo, confirmación y entrada.
- SL estructural y TP por RR; tamaño de lote calculado desde el riesgo real y especificaciones del símbolo del broker.
- Filtro de spread, slippage, duplicados, número máximo de operaciones, pérdida diaria y desconexiones.
- `EnableTrading=false` por defecto y bloqueo absoluto de órdenes reales hasta superar pruebas en demo.

No incluir contraseñas de Exness ni tokens privados dentro del código fuente público.
